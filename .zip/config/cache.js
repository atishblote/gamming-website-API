// cache.js
const NodeCache = require('node-cache');
const cache = new NodeCache();

module.exports = cache;
